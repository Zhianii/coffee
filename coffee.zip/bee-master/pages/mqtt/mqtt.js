// index.js
// 获取应用实例
const app = getApp()
var mqtt = require('../../utils/mqtt.min.js')

Page({
  data: {
  },
  onLoad:function(options) {
    var that = this
    that.connectMqtt()
    that.mqttSend()
    // this.connectMqtt()
  },

  connectMqtt:function(){
    const options = {
      connectTimeout:4000,
      // clientId:'a1b5mLmnO2C.device1|securemode=2,signmethod=hmacsha256,timestamp=1712497988068|',
      clientId:'8c9f3c084d10aabc82dd6d74edeaefee',
      port:8084,
      username:'8c9f3c084d10aabc82dd6d74edeaefee',
      password:'123456'
    }
    // client = mqtt.connect('wxs://a1b5mLmnO2C.iot-as-mqtt.cn-shanghai.aliyuncs.com:1883/mqtt',options)
    client = mqtt.connect('wxs://t.yoyolife.fun:8084/mqtt',options)
    
    client.on('connect',(e)=>
    {
      console.log('服务器连接成功')
      
      client.subscribe('/iot/5302/de',
      {
        qos:0, 
      },
      
      function(err)
      {
        if(!err)
        {
            console.log('订阅成功')
        }
      })
    })
    client.on('message',function(topic,message){
      console.log('收到'+message.toString())
    })
    
    client.on('connect', () => {
      client.subscribe('iot/5302/de')
    })

    client.on('connect', () => {
      client.publish('iot/5302/de', 'Hello, MQTT!')
      console.log("发送成功")
    })
  },

  mqttSend(msg) {
    
  },
  /**将ArrayBuffer转换成字符串*/
  ab2hex(buffer){
    var hexArr = Array.prototype.map.call(
      new Uint8Array(buffer),
        function (bit) {
          return ('00' + bit.toString(16)).slice(-2)
        }
      )
      return hexArr.join('');
  },

  taphere(){
      console.log('helloworld');
  }
})

